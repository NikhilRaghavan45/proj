﻿namespace MarkAttendance.Models
{
    public class Courses
    {
        public int CId { get; set; }
        public string CourseName { get; set; }
        public string CreatedBy { get; set; }
    }
}
