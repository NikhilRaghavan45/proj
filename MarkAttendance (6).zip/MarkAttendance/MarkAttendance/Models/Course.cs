﻿namespace MarkAttendance.Models
{
    public class Course
    {
        public int CId { get; set; }
        public string CName { get; set; }
        public int CDuration { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string Availability { get; set; }

        public string CDescription { get; set; }

        public string CPrequisite { get; set; }

        public string OutCome { get; set; }

    }
}
